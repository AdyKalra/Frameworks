Frameworkium-core [![Build Status][status-svg]][status]
=======================================================

## Release Notes

See the [Frameworkium Release Notes][release-notes].

## Usage

See the [Frameworkium example project][frameworkium] and associated [guidance][guidance] for usage.

[status-svg]: https://travis-ci.org/Frameworkium/frameworkium-core.svg?branch=master
[status]: https://travis-ci.org/Frameworkium/frameworkium-core
[release-notes]: https://github.com/Frameworkium/frameworkium-core/releases
[frameworkium]: https://github.com/Frameworkium/frameworkium
[guidance]: https://frameworkium.github.io/frameworkium/
