package com.frameworkium.integration.ai.capture.api.dto.executions;

/** Created execution message. */
public class ExecutionID {

    public String executionID;
}
